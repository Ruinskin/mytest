<html>
<body>
This is HTML message
</br>
<?php 
$c = 12;
$d = 2;
if($c > $d){echo "c is bigger";}
else{ echo "d is bigger";}
?>
</body>
</html>
